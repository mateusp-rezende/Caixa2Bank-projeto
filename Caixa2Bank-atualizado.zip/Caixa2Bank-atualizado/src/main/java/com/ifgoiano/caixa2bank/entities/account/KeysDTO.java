package com.ifgoiano.caixa2bank.entities.account;

public record KeysDTO(String cpf, String random, String email, String phone) {
}
