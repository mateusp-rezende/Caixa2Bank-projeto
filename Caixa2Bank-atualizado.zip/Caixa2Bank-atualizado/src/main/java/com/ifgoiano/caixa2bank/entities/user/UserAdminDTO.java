package com.ifgoiano.caixa2bank.entities.user;

public record UserAdminDTO(String username, String password, String cpf, String email, String phone) {
}
