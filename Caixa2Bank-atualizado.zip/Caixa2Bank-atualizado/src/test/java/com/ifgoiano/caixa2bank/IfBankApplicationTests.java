package com.ifgoiano.caixa2bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IfBankApplicationTests {

    @Test
    void contextLoads() {
    }

}
